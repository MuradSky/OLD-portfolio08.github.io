'use strict';

let gulp = require('gulp');
let sass = require('gulp-sass');
sass.compiler = require('node-sass');

let autoprefixer = require('gulp-autoprefixer');
let imagemin = require('gulp-imagemin');
// let rename = require('gulp-rename');
let browserSync = require('browser-sync');
// let cssbeautify = require('gulp-cssbeautify');
// let babel = require('gulp-babel');

gulp.task('html', function() {
    return gulp.src('app/*.html')
        .pipe(browserSync.reload({stream:true}))
});

// Sass TASK
gulp.task('scss', function(){
    return gulp.src('app/scss/**/*.scss')
        .pipe(sass({outputStyle: 'expanded'}))
        .pipe(autoprefixer(['last 15 versions', '> 1%', 'ie 8', 'ie 7'], { cascade: true }))
        .pipe(gulp.dest('app/css'))
        .pipe(browserSync.reload({stream:true}));
});

// SCRIPT TASK

gulp.task('script', function() {
    return gulp.src('src/js/*.js')
        .pipe(gulp.dest('app/js'))
        .pipe(browserSync.reload({stream:true}))
});






// Images TASK
gulp.task('images', function(){
    return gulp.src('app/img/**/*.{jpg,png,gif,svg,ico}')
        .pipe(imagemin())
        .pipe(browserSync.reload({stream:true}));
});




// WATCH TASK
gulp.task('watch', function(){
    gulp.watch('app/*.html', gulp.parallel('html'));
    gulp.watch('app/scss/**/*.scss', gulp.parallel('scss'));
    gulp.watch('app/js/**/*.js', gulp.parallel('script'));
    gulp.watch('app/img/**/*.{jpg,png,gif,svg,ico}', gulp.parallel('images'));
});



// Browser Sync
gulp.task('browser-sync', function(){
    browserSync.init({
        server: {
            baseDir: 'app/'
        }
    });
});

// Default TASK
gulp.task('default', gulp.parallel('scss', 'script', 'browser-sync', 'watch'))